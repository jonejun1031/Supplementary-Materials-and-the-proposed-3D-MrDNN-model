.. _hyperopt:

Hyperparameter Optimization
===========================

`chemprop.hyperparameter_optimization.py <https://github.com/chemprop/chemprop/tree/master/chemprop/hyperparameter_optimization.py>`_ runs hyperparameter optimization on Chemprop models.

.. automodule:: chemprop.hyperparameter_optimization
   :members:
