"""Trains a sklearn model on a dataset."""

from chemprop.sklearn_train import sklearn_train


if __name__ == '__main__':
    sklearn_train()
