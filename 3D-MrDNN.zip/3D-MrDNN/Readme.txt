Molecular Representation method is based on Yang's work (ref. 1).

Chemically Synthesizable Fragment Representation method is based on Zhu's work (ref. 2).

Molecular 3D Spatial Information Representation method is based on Zhou's work (ref. 3).

References:
1. K. Yang, K. Swanson, W. Jin, C. Coley, P. Eiden, H. Gao, A. Guzman-Perez, T. Hopper, B. Kelley, M. Mathea, A. Palmer, V. Settels, T. Jaakkola, K. Jensen and R. Barzilay, Analyzing Learned Molecular Representations for Property Prediction, J. Chem. Inf. Model., 2019, 59, 3370-3388.

2. W. Zhu, Y. Zhang, D. Zhao, J. Xu and L. Wang, HiGNN: A Hierarchical Informative Graph Neural Network for Molecular Property Prediction Equipped with Feature-Wise Attention, J. Chem. Inf. Model., 2023, 63, 43–55.

3. G. Zhou, Z. Gao, Q. Ding, H. Zheng, H. Xu, Z. Wei, L. Zhang and G. Ke, 2022.